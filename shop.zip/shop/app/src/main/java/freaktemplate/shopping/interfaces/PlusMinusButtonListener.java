package freaktemplate.shopping.interfaces;

public interface PlusMinusButtonListener {
    void plusClick(int position);

    void minusClick(int position);

    void removeClick(int position);
}
