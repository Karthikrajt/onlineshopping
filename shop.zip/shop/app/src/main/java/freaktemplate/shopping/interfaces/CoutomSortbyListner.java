package freaktemplate.shopping.interfaces;

public interface CoutomSortbyListner {

    void sortclick(int position);

    void brandClick(int position);

    void colorClick(int position);

    void sizeClick(int position);

    void priceClick(int position);

    void reviewClick(int position);
}
