package freaktemplate.shopping.getset;

public class TopOfferGetSet {

    private String brands;
    private String latest;
    private String save_upto;
    private String img_topoffer;

    public String getBrands() {
        return brands;
    }

    public void setBrands(String brands) {
        this.brands = brands;
    }

    public String getLatest() {
        return latest;
    }

    public void setLatest(String latest) {
        this.latest = latest;
    }

    public String getSave_upto() {
        return save_upto;
    }

    public void setSave_upto(String save_upto) {
        this.save_upto = save_upto;
    }

    public String getImg_topoffer() {
        return img_topoffer;
    }

    public void setImg_topoffer(String img_topoffer) {
        this.img_topoffer = img_topoffer;
    }
}
