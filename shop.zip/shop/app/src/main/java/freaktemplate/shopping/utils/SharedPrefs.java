package freaktemplate.shopping.utils;

public class SharedPrefs {


}
