package freaktemplate.shopping.getset;

public class OrderHeaderGetSet {

    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
