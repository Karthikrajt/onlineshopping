package freaktemplate.shopping.interfaces;

public interface OnBackPressed {
    void onBackPressed();
}
