package freaktemplate.shopping.interfaces;

import java.util.List;

import freaktemplate.shopping.getset.Detail.Optionvalue;

public interface SizeClick {
    void sizeClick(int position, List<Optionvalue> list);
}
