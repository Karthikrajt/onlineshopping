package freaktemplate.shopping.interfaces;

import android.widget.RadioButton;

public interface RadioListner {

    void RadioClick(int position,int mSelectedposition);

}
