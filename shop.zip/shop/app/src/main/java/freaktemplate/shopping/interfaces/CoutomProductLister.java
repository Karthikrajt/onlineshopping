package freaktemplate.shopping.interfaces;

public interface CoutomProductLister {

    void layoutClick(int position);

//    void likeClick(int position);

//    void dislikeClick(int position);

//    void cartClick(int position);
}
