package com.shreyaspatil.MaterialDialog.interfaces;

public interface DialogInterface {
    void cancel();
    void dismiss();
}
